---
name: "[Icon request] [App name] [...]"
about: Request [App name] icons
title: ''
labels: ''
assignees: ''

---

**Tell me things about the app or icon**
1. App name: (e.g Firefox Browser)
2. App Webside: or App Github Homepage: (e.g www.firefox.com)
3. App icon name: (e.g firefox)
    If you don't know the app name you can open the app desktop entry file,
    and find the line: icon=[App icon name] (e.g icon=firefox),
    the word after "icon=" is the App icon name.

    But if "icon=" is followed by the specific path of an icon file, then this app will not use icon theme 
    icons.  I generally don’t create this kind of icon because this app does not use it.

**Additional context**
Add any other context or screenshots about the icon request here.
